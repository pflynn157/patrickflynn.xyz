#include <QApplication>
#include <QMessageBox>
#include <QFileDialog>
#include <QFile>
#include <QTextStream>

#include "window.hpp"

// The constructor, where we setup our main window
Window::Window() {
    this->setWindowTitle("Simple Editor");
    this->resize(800, 500);
    
    // Init the editor
    editor = new QTextEdit;
    this->setCentralWidget(editor);
    
    // Init the menubar
    menubar = new QMenuBar;
    this->setMenuBar(menubar);
    
    fileMenu = new QMenu("File");
    editMenu = new QMenu("Edit");
    helpMenu = new QMenu("Help");
    
    menubar->addMenu(fileMenu);
    menubar->addMenu(editMenu);
    menubar->addMenu(helpMenu);
    
    // Init the file menu
    newFile = new QAction("New");
    openFile = new QAction("Open");
    saveFile = new QAction("Save File");
    saveFileAs = new QAction("Save File As");
    quitApp = new QAction("Quit");
    
    connect(newFile, &QAction::triggered, this, &Window::onNewFileClicked);
    connect(openFile, &QAction::triggered, this, &Window::onOpenFileClicked);
    connect(saveFile, &QAction::triggered, this, &Window::onSaveFileClicked);
    connect(saveFileAs, &QAction::triggered, this, &Window::onSaveFileAsClicked);
    connect(quitApp, &QAction::triggered, qApp, &QApplication::exit);
    
    fileMenu->addAction(newFile);
    fileMenu->addAction(openFile);
    fileMenu->addAction(saveFile);
    fileMenu->addAction(saveFileAs);
    fileMenu->addAction(quitApp);
    
    // Init the edit menu
    cut = new QAction("Cut");
    copy = new QAction("Copy");
    paste = new QAction("Paste");
    selectAll = new QAction("Select All");
    
    connect(cut, &QAction::triggered, this, &Window::onCutClicked);
    connect(copy, &QAction::triggered, this, &Window::onCopyClicked);
    connect(paste, &QAction::triggered, this, &Window::onPasteClicked);
    connect(selectAll, &QAction::triggered, this, &Window::onSelectAllClicked);
    
    editMenu->addAction(cut);
    editMenu->addAction(copy);
    editMenu->addAction(paste);
    editMenu->addAction(selectAll);
    
    // Init the help menu
    about = new QAction("About");
    aboutQt = new QAction("About Qt");
    
    connect(about, &QAction::triggered, this, &Window::onHelpClicked);
    connect(aboutQt, &QAction::triggered, qApp, &QApplication::aboutQt);
    
    helpMenu->addAction(about);
    helpMenu->addAction(aboutQt);
}

// The destructor, where we clean up any internal components
Window::~Window() {
}

// Writes the actual file content
void Window::save() {
    QFile file(path);
    if (file.open(QFile::WriteOnly)) {
        QTextStream writer(&file);
        writer << editor->toPlainText();
    }
}

//
// The slots for handling the file menu
//

// Creates a new file in the editor
void Window::onNewFileClicked() {
    path = "";
    editor->setText("");
}

// Opens a file and loads it to the editor
void Window::onOpenFileClicked() {
    QFileDialog dialog;
    dialog.setWindowTitle("Open");
    
    // If the dialog either doesn't run or doesn't have any selected
    // files, quietly return.
    //
    // In the real world, you would want to give the user an error message
    if (!dialog.exec() || dialog.selectedFiles().size() == 0) {
        return;
    }
    
    // This is a single-file editor, so only get the first selected file
    // The file dialog lets you select multiple files
    path = dialog.selectedFiles().at(0);
    
    // Now load the file
    QFile file(path);
    QString content = "";
    
    if (file.open(QFile::ReadOnly)) {
        QTextStream reader(&file);
        while (!reader.atEnd()) {
            content += reader.readLine() + "\n";
        }
    }
    
    editor->setText(content);
}

// Saves the file
void Window::onSaveFileClicked() {
    QFile file(path);
    if (!file.exists()) {
        onSaveFileAsClicked();
        return;
    }
    
    save();
}

// Saves the file and prompts the user for a destination
void Window::onSaveFileAsClicked() {
    QFileDialog dialog;
    dialog.setDirectory(QDir::homePath());                // Set default location to $HOME
    dialog.setAcceptMode(QFileDialog::AcceptSave);        // This dialog is for saving
    dialog.setWindowTitle("Save File As");
    
    // If nothing was selected or the dialog didn't work, quiety return
    if (dialog.exec() != QFileDialog::Accepted) {
        return;
    }
    
    // Set the path and save the file
    path = dialog.selectedFiles().at(0);
    save();
}

//
// The slots for handling the edit menu functions
//
void Window::onCutClicked() {
    editor->cut();
}

void Window::onCopyClicked() {
    editor->copy();
}

void Window::onPasteClicked() {
    editor->paste();
}

void Window::onSelectAllClicked() {
    editor->selectAll();
}

//
// The slots for the help menu
//
void Window::onHelpClicked() {
    QMessageBox msg;
    msg.setWindowTitle("About Simple Editor");
    msg.setText("Simple Editor\n"
                "A simple, cross-platform text editor written in C++ using the Qt libraries.\n");
    msg.setDetailedText("License: Public Domain\n");
    msg.setStandardButtons(QMessageBox::Ok);
    msg.exec();
}
    