#include <QApplication>

#include "window.hpp"

int main(int argc, char *argv[]) {
    // Before you can create an Qt objects, you have to create
    // a QApplication object
    QApplication app(argc, argv);
    
    Window win;
    win.show();
    
    return app.exec();
}