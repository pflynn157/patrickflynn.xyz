#pragma once

#include <QMainWindow>
#include <QFrame>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>
#include <QTextEdit>
#include <QMenuBar>
#include <QMenu>

// The class defining our main window
//
// We could use QWidget, but QMainWindow provides a lot
// more nice functions which make things easier, so unless you have
// a good reason it is better to use QMainWindow
//
class Window : public QMainWindow {
    Q_OBJECT
public:
    Window();
    ~Window();
private:
    QTextEdit *editor;
    QMenuBar *menubar;
    QMenu *fileMenu, *editMenu, *helpMenu;
    
    // File menu
    QAction *newFile, *openFile, *saveFile, *saveFileAs, *quitApp;
    
    // Edit menu
    QAction *cut, *copy, *paste, *selectAll;
    
    // Help Menu
    QAction *about, *aboutQt;
private slots:
    // Edit menu slots
    void onCutClicked();
    void onCopyClicked();
    void onPasteClicked();
    void onSelectAllClicked();
    
    // Help menu slots
    void onHelpClicked();
};
