#include <QApplication>
#include <QMessageBox>

#include "window.hpp"

// The constructor, where we setup our main window
Window::Window() {
    this->setWindowTitle("Simple Editor");
    this->resize(800, 500);
    
    // Init the editor
    editor = new QTextEdit;
    this->setCentralWidget(editor);
    
    // Init the menubar
    menubar = new QMenuBar;
    this->setMenuBar(menubar);
    
    fileMenu = new QMenu("File");
    editMenu = new QMenu("Edit");
    helpMenu = new QMenu("Help");
    
    menubar->addMenu(fileMenu);
    menubar->addMenu(editMenu);
    menubar->addMenu(helpMenu);
    
    // Init the file menu
    newFile = new QAction("New");
    openFile = new QAction("Open");
    saveFile = new QAction("Save File");
    saveFileAs = new QAction("Save File As");
    quitApp = new QAction("Quit");
    
    fileMenu->addAction(newFile);
    fileMenu->addAction(openFile);
    fileMenu->addAction(saveFile);
    fileMenu->addAction(saveFileAs);
    fileMenu->addAction(quitApp);
    
    // Init the edit menu
    cut = new QAction("Cut");
    copy = new QAction("Copy");
    paste = new QAction("Paste");
    selectAll = new QAction("Select All");
    
    connect(cut, &QAction::triggered, this, &Window::onCutClicked);
    connect(copy, &QAction::triggered, this, &Window::onCopyClicked);
    connect(paste, &QAction::triggered, this, &Window::onPasteClicked);
    connect(selectAll, &QAction::triggered, this, &Window::onSelectAllClicked);
    
    editMenu->addAction(cut);
    editMenu->addAction(copy);
    editMenu->addAction(paste);
    editMenu->addAction(selectAll);
    
    // Init the help menu
    about = new QAction("About");
    aboutQt = new QAction("About Qt");
    
    connect(about, &QAction::triggered, this, &Window::onHelpClicked);
    connect(aboutQt, &QAction::triggered, qApp, &QApplication::aboutQt);
    
    helpMenu->addAction(about);
    helpMenu->addAction(aboutQt);
}

// The destructor, where we clean up any internal components
Window::~Window() {
}

//
// The slots for handling the edit menu functions
//
void Window::onCutClicked() {
    editor->cut();
}

void Window::onCopyClicked() {
    editor->copy();
}

void Window::onPasteClicked() {
    editor->paste();
}

void Window::onSelectAllClicked() {
    editor->selectAll();
}

//
// The slots for the help menu
//
void Window::onHelpClicked() {
    QMessageBox msg;
    msg.setWindowTitle("About Simple Editor");
    msg.setText("Simple Editor\n"
                "A simple, cross-platform text editor written in C++ using the Qt libraries.\n");
    msg.setDetailedText("License: Public Domain\n");
    msg.setStandardButtons(QMessageBox::Ok);
    msg.exec();
}
    