#pragma once

#include <QMainWindow>
#include <QFrame>
#include <QVBoxLayout>
#include <QLabel>
#include <QPushButton>

// The class defining our main window
//
// We could use QWidget, but QMainWindow provides a lot
// more nice functions which make things easier, so unless you have
// a good reason it is better to use QMainWindow
//
class Window : public QMainWindow {
    Q_OBJECT
public:
    Window();
    ~Window();
private:
    QFrame *mainContent;
    QVBoxLayout *mainLayout;
    QLabel *label;
    QPushButton *button;
private slots:
    void onButtonClicked();
};
