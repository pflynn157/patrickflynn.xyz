#include "window.hpp"

// The constructor, where we setup our main window
Window::Window() {
    this->setWindowTitle("My First Window");
    this->resize(800, 500);
    
    // Create the main widget with the layout
    mainLayout = new QVBoxLayout;
    mainContent = new QFrame;
    mainContent->setLayout(mainLayout);
    this->setCentralWidget(mainContent);
    
    // Now, create the label
    label = new QLabel("Hello World!");
    mainLayout->addWidget(label, 0, Qt::AlignCenter);
    
    // Finally, create the button
    button = new QPushButton("Click Me!");
    mainLayout->addWidget(button, 0, Qt::AlignCenter);
    
    connect(button, &QPushButton::clicked, this, &Window::onButtonClicked);
}

// The destructor, where we clean up any internal components
Window::~Window() {
}

// Called when the button is clicked
void Window::onButtonClicked() {
    label->setText("Button Clicked!");
}