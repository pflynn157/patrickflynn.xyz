#include "window.hpp"

// The constructor, where we setup our main window
Window::Window() {
    this->setWindowTitle("Simple Editor");
    this->resize(800, 500);
}

// The destructor, where we clean up any internal components
Window::~Window() {
}
